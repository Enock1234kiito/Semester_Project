#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace std;

vector<string> words;

void initializeWords() {
    words.push_back("hangman");
    words.push_back("computer");
    words.push_back("programming");
    words.push_back("language");
    words.push_back("openai");
}

const int MAX_TRIES = 6;



void displayHangman(int incorrectGuesses) {
    // Display hangman ASCII art based on incorrect guesses
    // You can find simple ASCII art examples online
}

int main() {
    srand(time(0)); // Seed the random number generator
    initializeWords();
    

    string wordToGuess = words[rand() % words.size()];
    string guessedLetters = "";
    int incorrectGuesses = 0;

    while (incorrectGuesses < MAX_TRIES) {
        displayHangman(incorrectGuesses);

        bool allLettersGuessed = true;
      for (size_t i = 0; i < wordToGuess.size(); ++i) {
    char letter = wordToGuess[i];
            if (guessedLetters.find(letter) == string::npos) {
                cout << "_ ";
                allLettersGuessed = false;
            } else {
                cout << letter << " ";
            }
        }
        cout << endl;

        if (allLettersGuessed) {
            cout << "Congratulations, you've guessed the word!" << endl;
            break;
        }

        cout << "Guess a letter: ";
        char guess;
        cin >> guess;

        if (guessedLetters.find(guess) != string::npos) {
            cout << "You've already guessed that letter." << endl;
            continue;
        }

        guessedLetters += guess;

        if (wordToGuess.find(guess) == string::npos) {
            incorrectGuesses++;
            cout << "Incorrect guess. You have " << MAX_TRIES - incorrectGuesses << " tries left." << endl;
        }
    }

    if (incorrectGuesses == MAX_TRIES) {
        displayHangman(incorrectGuesses);
        cout << "You've run out of tries. The word was: " << wordToGuess << endl;
    }

    return 0;
}
